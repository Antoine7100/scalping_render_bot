# Point d'entrée du bot
print('Bot prêt à être déployé.')